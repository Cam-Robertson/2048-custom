var config_2048 = {
  rank    : 4,
  title   : '十二月的奇迹',
  intro   : '报复社会',
  author  : '害羞的作者没有留下自己的名字',
  created : '2014-03-27 13:38',
  visited : 83706,
  data : [
    'http://ww4.sinaimg.cn/large/7f7fe085tw1eeu8vrcpmcj209209274l.jpg',
    'http://ww2.sinaimg.cn/large/7f7fe085tw1eeu8vqqb5aj2092092q38.jpg',
    'http://ww2.sinaimg.cn/large/7f7fe085tw1eeu957poezj203g03tgli.jpg',
    'http://ww1.sinaimg.cn/large/7f7fe085tw1eeu8vpog1vj2092092jrm.jpg',
    'http://ww2.sinaimg.cn/large/7f7fe085tw1eeu8vqsoy4j2092092jrm.jpg',
    'http://ww3.sinaimg.cn/large/7f7fe085tw1eeu8vp9orfj2092092wet.jpg',
    'http://ww3.sinaimg.cn/large/7f7fe085tw1eeu8voznz5j2092092t8z.jpg',
    'http://ww1.sinaimg.cn/large/7f7fe085tw1eeu8votzkbj20920923yu.jpg',
    'http://ww1.sinaimg.cn/large/7f7fe085tw1eeu8vomdx4j2092092wes.jpg',
    'http://ww4.sinaimg.cn/large/7f7fe085tw1eeu8vrcpmcj209209274l.jpg',
    'http://ww2.sinaimg.cn/large/7f7fe085tw1eeu8vr27gnj20920923ys.jpg',
    'http://ww4.sinaimg.cn/large/7f7fe085tw1eeu8vq0rcrj2092092dg3.jpg'
  ],
  mark : [
    'Game Over, HiScore: 2',
    'Game Over, HiScore: 4',
    'Game Over, HiScore: 8'],
  goal : 2048,
  done : 'You Win!'
}